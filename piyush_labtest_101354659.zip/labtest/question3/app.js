const progressBar = require('./progress-bar');

progressBar.startProgress();
