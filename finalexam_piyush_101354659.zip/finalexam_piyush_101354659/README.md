Student Name : Piyush Rajkumar Himmatsinghka
Student ID : 101354659

Instructions:

Create Output.txt by running 

npm app.js

To create Zip file run:

npm pipe.js